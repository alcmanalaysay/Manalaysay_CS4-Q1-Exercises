package exercise01;


public class Exercise01 {
  public static void main(String[] args) {
  //object1
    String m1brand = "Bear Brand";
    String m1flavor = "plain";
    int m1calories = 124;
    double m1ounce = 6.7628;
    
    System.out.println("Milk 1");
    System.out.println("Brand: " + m1brand);
    System.out.println("Flavor: " + m1flavor); 
    System.out.println("Calories: " + m1calories);  
    System.out.println("Fluid Ounces: " + m1ounce);     

  //object2
    String m2brand = "Soyfresh";
    String m2flavor = "strawberry";
    int m2calories = 140;
    double m2ounce = 8.45351;
    
    System.out.println( "\nMilk 2");
    System.out.println("Brand: " + m2brand);
    System.out.println("Flavor: " + m2flavor); 
    System.out.println("Calories: " + m2calories); 
    System.out.println("Fluid Ounces: " + m2ounce);  
    
  //object3
    String m3brand = "Soy Secretz";
    String m3flavor = "Sweet Corn";
    int m3calories = 151;
    double m3ounce = 7.77723;   
    
    System.out.println("\nMilk 3");
    System.out.println("Brand: " + m3brand);
    System.out.println("Flavor: " + m3flavor); 
    System.out.println("Calories: " + m3calories); 
    System.out.println("Fluid Ounces: " + m3ounce);  

  //operations
    boolean sameBrand = false;
    boolean diffFlavors = true;
    int totalCalories = m1calories + m2calories + m3calories;
    double totalOunces = m1ounce + m2ounce + m3ounce; 
    
    System.out.println("\nThe drinks all came from the same brand: " + sameBrand);
    System.out.println("The drinks had different flavors: " + diffFlavors); 
    System.out.println("Total Calories: " + totalCalories); 
    System.out.println("Total Amount in Fluid Ounces: " + totalOunces);   
  }

}

