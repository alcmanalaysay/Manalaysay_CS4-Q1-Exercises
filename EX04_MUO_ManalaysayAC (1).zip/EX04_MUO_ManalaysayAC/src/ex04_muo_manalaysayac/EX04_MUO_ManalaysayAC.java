/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ex04_muo_manalaysayac;

import java.util.Scanner;

/**
 *
 * @author Mu15_Alicia Manalaysay
 */

public class EX04_MUO_ManalaysayAC { 
    private static Move scissors;
    private static Move paper;
    private static Move rock;
    
    public static void main(String[] args) {
        scissors = new Move("Scissors");
        paper = new Move("Paper");
        rock = new Move("Rock");
        
        Scanner scan = new Scanner(System.in);
        int playerScore = 0;
        int computerScore = 0;
        int roundsToWin = 2;
        
        System.out.print("Welcome to Rock, Paper, Scissors. ");
        System.out.println("Please choose an option:");
        System.out.println("1. Start game");
        System.out.println("2. Change number of rounds");
        System.out.println("3. Exit application");

        int choice = scan.nextInt();
        while (choice != 3) {
            switch (choice) {
                case 1:                 {   
                    {
                        System.out.println("This match will be first to " + roundsToWin + " wins.");
                    }
                    while (playerScore < roundsToWin && computerScore < roundsToWin) {
                        System.out.println("The computer has selected its move.");
                        System.out.println("Select your move:");
                        System.out.println("1. Rock");
                        System.out.println("2. Paper");
                        System.out.println("3. Scissors");
                        
                        int playerMove = scan.nextInt();
                        
                        int computerMove = (int) Math.floor(Math.random()*3) + 1;
                        
                        Move playerMoveObj, computerMoveObj;
                        
                        playerMoveObj = switch (playerMove) {
                            case 1 -> rock;
                            case 2 -> paper;
                            default -> scissors;
                        };
                        
                        
                        computerMoveObj = switch (computerMove) {
                            case 1 -> rock;
                            case 2 -> paper;
                            default -> scissors;
                        };
                        
                        System.out.println("Player chose " + playerMoveObj.getName() + ".");
                        System.out.println("Computer chose " + computerMoveObj.getName() + ".");
                        
                        int result = Move.compareMoves(playerMoveObj, computerMoveObj);
                        
                        switch (result) {
                            case 0: {
                                System.out.println("Player wins round!");
                                playerScore++;
                            }
                            case 1: {
                                System.out.println("Computer wins round!");
                                computerScore++;
                            }
                            default:
                                System.out.println("Round is tied!");
                        }
                        
                        System.out.println("Player: " + playerScore + " - Computer: " + computerScore);
                    }
                    if (playerScore > computerScore) {
                        System.out.println("Player wins!");
                    } else {
                        System.out.println("Computer wins!");
                    }
                    break;
                }


                case 2: {
                    System.out.println("How many wins are needed to win a match?");
                    roundsToWin = scan.nextInt();
                    System.out.println("New setting has been saved!");
                    break;
                }
                
                default: System.out.println("The value you inputted is invalid. Please try again.");
            }

            System.out.println();
            System.out.print("Welcome to Rock, Paper, Scissors.");
            System.out.println("Please choose an option:");
            System.out.println("1. Start game");
            System.out.println("2. Change number of rounds");
            System.out.println("3. Exit application");

            choice = scan.nextInt();
        }

        System.out.println("Thank you for playing!");
    }
}
