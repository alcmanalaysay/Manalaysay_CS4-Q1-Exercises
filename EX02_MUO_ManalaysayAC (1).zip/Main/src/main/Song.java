/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;

/**
 *
 * @author Alicia
 */
public class Song {
    String title;
    
    public Song(String title){
        this.title =  title;
    }

    /* String getTitle() {
        return title; 
    } */
}
