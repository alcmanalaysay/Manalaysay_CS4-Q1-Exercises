/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package main;

/**
 *
 * @author Alicia
 */
public class Main {

    public static void main(String[] args) {
        //3 instances of the Random class
        Random p1 = new Random("Anna", 21);
        Random p2 = new Random("Mark", 32);
        Random p3 = new Random("Sarah", 17);
     
         
        //2 instances of the Song class
        Song so1 = new Song ("You Belong With Me");
        Song so2 = new Song ("Lovestruck");
        
        //setting s1 and number of audience
        Singer s1 = new Singer ("Lizzy McAlpine");
        int noOfAudiences = 12;
        s1.perfForAudience(12);
        
        //setting new favorite song
        Song newFavSong = new Song ("Ceilings");
        s1.changeFavSong(newFavSong);
        
        //print the output
        System.out.println(s1 + " performed to " + noOfAudiences + " audiences.");
        System.out.println("lizzy McAlpine's favorite song is changed to " + newFavSong);
    }
}
