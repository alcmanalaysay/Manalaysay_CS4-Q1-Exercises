/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;

/**
 *
 * @author Alicia
 */
public class Singer {
    String name;
    int noOfPerformances;
    double earnings;
    Song favSong;
    
    public Singer (String name); {
        this.name = name;
    }
    
    public Singer (String name, int noOfPerformances, double earnings, Song favSong); {
        this.name = name;
        this.noOfPerformances = noOfPerformances;
        this.earnings = earnings;
        this.favSong = favSong;
    }
    
    public void perfForAudience (int numOfAudi){
        int inc = numOfAudi*100; //mutiplies audience number by 100
        noOfPerformances++;
        earnings += inc; //setting the increase as the earning
    }
    
    public void changeFavSong(Song newSong) {
        favSong = newSong; //setting newSong as the favSong
    }
}
