/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex05_muo_manalaysayac;

/**
 *
 * @author Mu15 MANALAYSAY
 */
import java.util.*;

public class Store {
  private String name;
  private double earnings;
  private ArrayList<Item> itemList;
  private static ArrayList<Store> storeList = new ArrayList();

  public Store(String name){
    this.name = name;
    // Initialize name to parameter and earnings to zero
    this.earnings = 0;
    // Initialize itemList as a new ArrayList
    this.itemList = new ArrayList<>();
    storeList.add(this);
    // add 'this' store to storeList
  }

  public String getName(){
    return name;
  }
  public double getEarnings(){
    return earnings;
  }
  public void sellItem(int index){
    if (index >= 0 && index < itemList.size()) {     // check if index is within the size of the itemList (if not, print statement that there are only x items in the store)
      Item item = itemList.get(index);     // get Item at index from itemList and add its cost to earnings
      earnings += item.getCost();
      System.out.println("\nSold " + item.getName() + " for ₱" + item.getCost());
    } else {
      System.out.println("There are only " + itemList.size() + " items in the store.");     // print statement indicating the sale
    }
  }
  public void sellItem(String name){
    for (Item item : itemList) {     // check if Item with given name is in the itemList (you will need to loop over itemList) (if not, print statement that the store doesn't sell it)
      if (item.getName().equals(name)) {     // get Item from itemList and add its cost to earnings
        earnings += item.getCost();
        System.out.println("Sold " + item.getName() + " for ₱" + item.getCost());     // print statement indicating the sale
        return;
      }
    }
    System.out.println("The store doesn't sell " + name + ".");
  }
  public void sellItem(Item i){
    if (itemList.contains(i)) {     // check if Item i exists in the store (there is a method that can help with this) (if not, print statement that the store doesn't sell it)
      earnings += i.getCost();     // get Item i from itemList and add its cost to earnings
      System.out.println(i.getName() + " - ₱" + i.getCost());
    } else {
      System.out.println("The store doesn't sell " + i.getName() + ".");     // print statement indicating the sale
    }
  }
  public void addItem(Item i){
    itemList.add(i);    // add Item i to store's itemList
  }
  public void filterType(String type){
    System.out.println("Items that are " + type + ":");
    for (Item item : itemList) {    // loop over itemList and print all items with the specified type
      if (item.getType().equals(type)) {
        System.out.println(item.getName() + " - ₱" + item.getCost());
      }
    }  
  }
  public void filterCheap(double maxCost){
    System.out.println("\nItems that cost less than or equal to ₱" + maxCost + ":");
    for (Item item : itemList) {  // loop over itemList and print all items with a cost lower than or equal to the specified value
      if (item.getCost() <= maxCost) {
        System.out.println(item.getName() + " - ₱" + item.getCost());
      }
    }   
  }
  public void filterExpensive(double minCost){
      System.out.println("\nItems that cost greater than or equal to ₱" + minCost + ":");
    for (Item item : itemList) {   // loop over itemList and print all items with a cost higher than or equal to the specified value
      if (item.getCost() >= minCost) {
        System.out.println(item.getName() + " - ₱" + item.getCost());
      }
    }  
  }
  public static void printStats(){
    for (Store store : storeList) {     // loop over storeList and print the name and the earnings'Store.java'
      System.out.println("\nStore: " + store.getName());
      System.out.println("Earnings: ₱" + store.getEarnings());
    }
  }   
}

