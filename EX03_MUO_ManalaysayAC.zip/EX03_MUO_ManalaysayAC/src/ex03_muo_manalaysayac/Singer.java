/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex03_muo_manalaysayac;

/**
 *
 * @author Alicia
 */
class Singer {
    private String name;
    private int noOfPerf;
    private double earnings;
    private Song favSong;
    private static int totalPerf = 0;

    public Singer(String name) {
        this.name = name;
        noOfPerf = 0;
        earnings = 0;
    }

    public String getName() {
        return name;
    }

    public int getNoOfPerf() {
        return noOfPerf;
    }

    public double getEarnings() {
        return earnings;
    }

    public Song getFavSong() {
        return favSong;
    }

    public static int getTotalPerf() {
        return totalPerf;
    }

    public void perfForAudience(int noOfPeople) {
        noOfPerf++;
        earnings += noOfPeople * 100;
        totalPerf++;
    }

    public void perfWithOtherSinger(Singer otherSinger, int noOfPeople) {
        perfForAudience(noOfPeople / 2);
        otherSinger.perfForAudience(noOfPeople / 2);
    }

    public void changeFavSong(Song newSong) {
        favSong = newSong;
    }
}
  