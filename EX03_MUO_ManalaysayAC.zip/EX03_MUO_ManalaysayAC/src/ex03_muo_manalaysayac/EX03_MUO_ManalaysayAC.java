/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ex03_muo_manalaysayac;

/**
 *
 * @author Alicia
 */
public class EX03_MUO_ManalaysayAC {
    
   public static void main(String[] args) {
        //3 instances of the Random class
        Random p1 = new Random("Anna", 21);
        Random p2 = new Random("Mark", 32);
        Random p3 = new Random("Sarah", 17);

          
        //2 instances of the Song class
        Song so1 = new Song ("You Belong With Me");
        Song so2 = new Song ("Lovestruck");

        //declaration of singer 1
        Singer singer1 = new Singer("Lola Amour");
        singer1.changeFavSong(so1);
        singer1.perfForAudience(12);
        singer1.changeFavSong(so2);

        //declaration of singer 2
        Singer singer2 = new Singer("Sunkissed Lola");
        singer2.changeFavSong(so2);
        singer2.perfForAudience(10);

        //declaration of singer 3
        Singer singer3 = new Singer("SOS");
        singer3.changeFavSong(so1);
        singer3.perfWithOtherSinger(singer2, 15);
         
        //output to show total number of performances
        System.out.println("Singer 1 no. of performances: " + singer1.getNoOfPerf());
        System.out.println("Singer 2 no. of performances: " + singer2.getNoOfPerf());
        System.out.println("Singer 3 no. of performances: " + singer3.getNoOfPerf());
        System.out.println("Total no. of performances: " + Singer.getTotalPerf());
    }
}
